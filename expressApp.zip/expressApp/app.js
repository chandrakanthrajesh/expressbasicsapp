const express = require('express');
const path = require('path');
const app = express();
//const logger = require('./middleware/logger');
const exphbs = require('express-handlebars');



app.engine('handlebars',exphbs({ defaultLayout: 'main'}));  //creating a view engine by name handlebar and setting layout to main
app.set('view engine','handlebars');

app.use('/api/members',require('./routes/controller'));


//init middleware
//app.use(logger);
// app.get('/',(req,res) => {
//     res.render('index');
// });

app.use(express.static(path.join(__dirname,'public')));  //dirname means current directory,  point to public

const PORT  = process.env.PORT || 5000;   //first server will check environment PORT if not available then run in 5000
app.listen(PORT, () => console.log(`Server started on port ${PORT}!`));


