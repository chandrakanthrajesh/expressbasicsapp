const members = [
    {
        id: 1,
        name: 'ck',
        email: 'ck@gmail.com',
        status: 'active'
    },
    {
        id: 2,
        name: 'ok',
        email: 'ok@gmail.com',
        status: 'inactive'
    },
    {
        id: 3,
        name: 'pk',
        email: 'pk@gmail.com',
        status: 'active'
    },

];

module.exports = members; 